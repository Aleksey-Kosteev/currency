//
//  ContentView.swift
//  Currency
//
//  Created by Aleksey on 10.02.22.
//

import SwiftUI

struct ContentView: View {
    @State private var itemSelected = 0
    @State private var itemSelected2 = 1
    @State private var amount : String = ""
    private let currencies = ["🇧🇾 BYN", "🇪🇺 EUR", "🇷🇺 RUB", "🇺🇸 USD"]

    func convert(_ convert: String) -> String {
        var conversion: Double = 1.0
        let amount = Double(convert.doubleValue)
        let selectedCurrency = currencies[itemSelected]
        let to = currencies[itemSelected2]
        
        let bynRates = ["🇧🇾 BYN": 1.0, "🇪🇺 EUR": 0.34, "🇷🇺 RUB": 29.15, "🇺🇸 USD": 0.39]
        let euroRates = ["🇧🇾 BYN": 2.92, "🇪🇺 EUR": 1.0, "🇷🇺 RUB": 85.19, "🇺🇸 USD": 1.14]
        let rubRates = ["🇧🇾 BYN": 0.03, "🇪🇺 EUR": 0.01, "🇷🇺 RUB": 1.0, "🇺🇸 USD": 0.01]
        let usdRates = ["🇧🇾 BYN": 2.56, "🇪🇺 EUR": 0.88, "🇷🇺 RUB": 74.64, "🇺🇸 USD": 1.0]
        
        switch (selectedCurrency) {
        case "🇧🇾 BYN" :
            conversion = amount * (bynRates[to] ?? 0.0)
        case "🇪🇺 EUR" :
            conversion = amount * (euroRates[to] ?? 0.0)
        case "🇷🇺 RUB" :
            conversion = amount * (rubRates[to] ?? 0.0)
        case "🇺🇸 USD" :
            conversion = amount * (usdRates[to] ?? 0.0)
        default:
            print("что-то пошло не так!")
        }
        
        
        return String(format: "%.2f", conversion)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Конвертировать валюту")) {
                    TextField("Введите сумму", text: $amount)
                        .keyboardType(.decimalPad)
                    
                    Picker(selection: $itemSelected, label: Text("Из")) {
                        ForEach(0..<currencies.count) { index in Text(self.currencies[index]).tag(index)
                        }
                    }
                    Picker(selection: $itemSelected2, label: Text("В")) {
                        ForEach(0..<currencies.count) { index in Text(self.currencies[index]).tag(index)
                        }
                    }
                }
                Section(header: Text("Результат")) {
                    Text("\(convert(amount)) \(currencies[itemSelected2])")
                }
            
            
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
