//
//  CurrencyApp.swift
//  Currency
//
//  Created by Aleksey on 10.02.22.
//

import SwiftUI

@main
struct CurrencyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
